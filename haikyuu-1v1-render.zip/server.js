const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true }));

const rooms = new Map();
const WIDTH = 900, FLOOR = 410, GRAVITY = 0.34;

function makeRoom(code) {
  return {
    code, players: [], score: [0, 0], phase: "waiting",
    ball: { x: 190, y: 310, vx: 0, vy: 0, r: 13 },
    lastHit: -1, pointTimer: 0, updatedAt: Date.now()
  };
}
function publicState(room) {
  return {
    code: room.code, score: room.score, phase: room.phase,
    players: room.players.map(p => ({
      id: p.id, side: p.side, x: p.x, y: p.y, vx: p.vx, vy: p.vy,
      grounded: p.grounded, pose: p.pose, ready: true
    })),
    ball: room.ball
  };
}
function resetRally(room) {
  room.ball = { x: room.score[0] + room.score[1] % 2 === 0 ? 190 : 710, y: 310, vx: 0, vy: 0, r: 13 };
  // Correct the serve position without relying on score precedence.
  room.ball.x = (room.score[0] + room.score[1]) % 2 === 0 ? 190 : 710;
  room.phase = "serve";
  room.lastHit = -1;
  room.players.forEach(p => {
    p.x = p.side === 0 ? 170 : 730;
    p.y = FLOOR; p.vx = 0; p.vy = 0; p.grounded = true; p.pose = "idle";
  });
}
function emitRoom(room) { io.to(room.code).emit("state", publicState(room)); }

io.on("connection", socket => {
  socket.on("joinRoom", raw => {
    const code = String(raw || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6);
    if (code.length < 4) return socket.emit("notice", "Code invalide (4 à 6 caractères).");
    let room = rooms.get(code);
    if (!room) { room = makeRoom(code); rooms.set(code, room); }
    if (room.players.length >= 2) return socket.emit("notice", "Cette salle est déjà pleine.");
    if (room.players.some(p => p.id === socket.id)) return;
    const side = room.players.length;
    room.players.push({
      id: socket.id, side, x: side === 0 ? 170 : 730, y: FLOOR,
      vx: 0, vy: 0, grounded: true, pose: "idle", input: { dir: 0 },
      lastAction: 0
    });
    socket.join(code);
    socket.data.room = code;
    socket.data.side = side;
    socket.emit("joined", { code, side });
    room.phase = room.players.length === 2 ? "serve" : "waiting";
    emitRoom(room);
  });

  socket.on("input", data => {
    const room = rooms.get(socket.data.room);
    if (!room) return;
    const p = room.players.find(x => x.id === socket.id);
    if (!p) return;
    p.input.dir = Math.max(-1, Math.min(1, Number(data?.dir) || 0));
  });

  socket.on("action", action => {
    const room = rooms.get(socket.data.room);
    if (!room || room.players.length !== 2 || room.phase === "waiting" || room.phase === "over") return;
    const p = room.players.find(x => x.id === socket.id);
    if (!p) return;
    const now = Date.now();
    if (now - p.lastAction < 120) return;
    p.lastAction = now;

    if (action === "jump" && p.grounded) {
      p.vy = -10.5; p.grounded = false; p.pose = "jump";
    }
    if (action === "serve" && room.phase === "serve") {
      const dir = p.side === 0 ? 1 : -1;
      room.ball = { x: p.x + dir * 28, y: p.y - 100, vx: dir * 7.3, vy: -5.2, r: 13 };
      room.phase = "playing";
      p.pose = "serve";
    }
    if ((action === "pass" || action === "smash") && room.phase === "playing") {
      const b = room.ball;
      const d = Math.hypot(b.x - p.x, b.y - (p.y - 65));
      if (d < 118 && (action !== "smash" || !p.grounded)) {
        const dir = p.side === 0 ? 1 : -1;
        b.vx = dir * (action === "smash" ? 9.5 : 7.0);
        b.vy = action === "smash" ? -7.0 : -5.4;
        room.lastHit = p.side;
        p.pose = action;
      }
    }
  });

  socket.on("disconnect", () => {
    const code = socket.data.room;
    const room = rooms.get(code);
    if (!room) return;
    room.players = room.players.filter(p => p.id !== socket.id);
    room.phase = "waiting";
    io.to(code).emit("notice", "Un joueur a quitté la salle.");
    emitRoom(room);
    if (!room.players.length) rooms.delete(code);
  });
});

// Lightweight authoritative simulation.
setInterval(() => {
  for (const room of rooms.values()) {
    if (room.players.length !== 2) continue;
    if (room.phase === "point") {
      room.pointTimer -= 1 / 30;
      if (room.pointTimer <= 0) resetRally(room);
      emitRoom(room); continue;
    }
    if (room.phase !== "playing") { emitRoom(room); continue; }

    for (const p of room.players) {
      const dir = p.input.dir;
      p.vx = dir * 4.0;
      p.x += p.vx;
      p.x = p.side === 0 ? Math.max(25, Math.min(420, p.x)) : Math.max(480, Math.min(875, p.x));
      if (!p.grounded) {
        p.vy += GRAVITY;
        p.y += p.vy;
        if (p.y >= FLOOR) { p.y = FLOOR; p.vy = 0; p.grounded = true; p.pose = "idle"; }
      }
      if (Math.abs(dir) > 0.1 && p.grounded && p.pose === "idle") p.pose = "run";
      if (Math.abs(dir) <= 0.1 && p.pose === "run") p.pose = "idle";
    }

    const b = room.ball;
    b.vy += 0.19;
    b.x += b.vx; b.y += b.vy;
    if (b.x > 435 && b.x < 465 && b.y > 195) { b.vx *= -0.65; b.x = b.x < 450 ? 432 : 468; }
    if (b.y < 20) { b.y = 20; b.vy = Math.abs(b.vy) * 0.6; }

    // Score if the ball reaches the floor or leaves the playable area.
    if (b.y >= FLOOR - b.r || b.x < 0 || b.x > WIDTH || b.y > FLOOR + 30) {
      const winner = b.x < 450 ? 1 : 0;
      room.score[winner]++;
      room.phase = "point";
      room.pointTimer = 1.4;
      if (room.score[winner] >= 15 && room.score[winner] - room.score[1-winner] >= 2) room.phase = "over";
    }
    emitRoom(room);
  }
}, 1000 / 30);

server.listen(PORT, () => console.log(`Haikyuu 1v1 running on ${PORT}`));
