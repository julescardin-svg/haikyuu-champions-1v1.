# Haikyuu Champions — 1v1 en ligne

## Fonctionnalités
- Jeu de volley 1 contre 1 en vue latérale.
- Salles avec code à partager.
- Synchronisation via Socket.IO.
- Gravité du ballon et des joueurs, saut, passe, smash et service.
- Graphismes dessinés en Canvas (terrain, gymnase, tribunes, joueurs et ballon).

## Déploiement gratuit sur Render
1. Crée un compte Render et un dépôt GitHub.
2. Décompresse ce projet et ajoute tous les fichiers à un dépôt GitHub.
3. Sur Render, choisis **New + → Blueprint** puis sélectionne le dépôt.
4. Render détectera `render.yaml`. Vérifie que le service `haikyuu-1v1` est sur le plan gratuit, puis lance le déploiement.
5. Ouvre l'URL `https://...onrender.com` fournie par Render.
6. Un joueur clique sur **Créer une salle**, puis envoie le code à son ami. L'ami ouvre la même URL, saisit le code et clique sur **Rejoindre**.

## Notes
- Le service gratuit peut se mettre en veille après inactivité; le premier démarrage peut donc être lent.
- Pour jouer, les deux joueurs doivent rejoindre la même salle.
- Ce projet est un prototype jouable. La physique est volontairement simple et pourra être équilibrée/améliorée.
- Projet de fan non officiel, sans affiliation avec Haikyuu!! ou ses ayants droit.
